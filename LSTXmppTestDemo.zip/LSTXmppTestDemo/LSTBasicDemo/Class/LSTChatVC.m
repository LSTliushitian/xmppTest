//
//  LSTChatVC.m
//  LSTBasicDemo
//
//  Created by 兰科 on 2018/8/2.
//  Copyright © 2018年 兰科. All rights reserved.
//

#import "LSTChatVC.h"
#import "ChatModel.h"

#import "UUInputFunctionView.h"
#import "UUMessageCell.h"
#import "UUMessageFrame.h"
#import "UUMessage.h"
#import "UUChatCategory.h"

@interface LSTChatVC ()<UUInputFunctionViewDelegate,UUMessageCellDelegate,UITableViewDataSource,UITableViewDelegate>
{
    CGFloat _keyboardHeight;
    UUInputFunctionView * _inputFuncView;
    CGRect _chatTableViewFrame;
}
@property (nonatomic, strong) ChatModel *chatModel;
@property (nonatomic, strong) UITableView * chatTableView;//聊天视图

@end

@implementation LSTChatVC

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    //add notificationc
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillHideNotification object:nil];
    
    //展示最新消息
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(tableViewScrollToBottom) name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNewsMessage:) name:@"DidReceiveNewMessage" object:nil];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:({
        _chatTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, SafeAreaTopHeight, SCREENWIDTH, SCREENHEIGHT-SafeAreaTopHeight-SafeAreaBottomHeight+49-40) style:UITableViewStylePlain];
        _chatTableViewFrame = _chatTableView.frame;
        _chatTableView.delegate = self;
        _chatTableView.dataSource = self;
        __weak typeof(self) weakSelf = self;
        _chatTableView.mj_header = [MJRefreshHeader headerWithRefreshingBlock:^{
            [weakSelf.chatModel addRandomItemsToDataSource:3];
            [weakSelf.chatTableView reloadData];
        }];
        
        _chatTableView;
    })];
    
    [self.view addSubview:({
        _inputFuncView = [[UUInputFunctionView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT-SafeAreaBottomHeight+49-40, SCREENWIDTH, 40)];
        _inputFuncView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
        _inputFuncView.delegate = self;
        
        _inputFuncView;
    })];
    
    self.chatModel = [[ChatModel alloc]init];
    
    //从本地数据库获取历史消息
    [self.chatModel getMessageHistoryWithJID:_chatJID];
    [self.chatTableView reloadData];
    [self tableViewScrollToBottom];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    if (_inputFuncView.textViewInput.isFirstResponder) {
        CGRect rect = _chatTableViewFrame;
        rect.size.height = rect.size.height-_keyboardHeight;
        _chatTableView.frame = rect;
        _inputFuncView.frame = CGRectMake(0, _chatTableView.uu_bottom, self.view.uu_width, 40);
    } else {
        _chatTableView.frame = _chatTableViewFrame;
        _inputFuncView.frame = CGRectMake(0, _chatTableView.uu_bottom, self.view.uu_width, 40);
    }
}

#pragma mark - Notification
-(void)keyboardChange:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardEndFrame;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    
    _keyboardHeight = keyboardEndFrame.size.height;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:animationCurve];
    
    self.chatTableView.uu_height = self.view.uu_height - _inputFuncView.uu_height;
    self.chatTableView.uu_height -= notification.name == UIKeyboardWillShowNotification ? _keyboardHeight:0;
    self.chatTableView.contentOffset = CGPointMake(0, self.chatTableView.contentSize.height-self.chatTableView.uu_height);
    
    _inputFuncView.uu_top = self.chatTableView.uu_bottom;
    
    [UIView commitAnimations];
}

- (void)tableViewScrollToBottom
{
    if (self.chatModel.dataSource.count==0)
        return;
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.chatModel.dataSource.count-1 inSection:0];
    [self.chatTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(void)handleNewsMessage:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    XMPPMessageArchiving_Message_CoreDataObject *recordMessage = userInfo[@"message"];
    NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
    
    NSString *myStr = @"http://img0.bdstatic.com/img/image/shouye/xinshouye/mingxing16.jpg";
    NSString *otherStr =@"http://p1.qqyou.com/touxiang/uploadpic/2011-3/20113212244659712.jpg";
    
    //对方发的消息，显示在左边
    BOOL fromOthers = recordMessage.message.from;
    
    [dataDic setObject:fromOthers ? @(UUMessageFromOther):@(UUMessageFromMe) forKey:@"from"];
    [dataDic setObject:[recordMessage.timestamp description] forKey:@"strTime"];
    [dataDic setObject:fromOthers?recordMessage.bareJid.user:[LSTXXMMPStream sharedInstance].xmppJID.user forKey:@"strName"];
    [dataDic setObject:fromOthers ? otherStr:myStr forKey:@"strIcon"];
    
    //type:voice text picture
    NSNumber  *type;
    if ([recordMessage.message.subject isEqualToString:@"voice"]) {

        type = @(2);
        [dataDic setObject:[NSData dataWithContentsOfFile:recordMessage.body] forKey:@"voice"];
        [dataDic setObject:@([recordMessage.message attributeIntValueForName:@"VoiceLength"]) forKey:@"strVoiceTime"];
    }else if ([recordMessage.message.subject isEqualToString:@"picture"]){
        type = @(1);
        [dataDic setObject:[UIImage imageNamed:recordMessage.body] forKey:@"picture"];
        
    }else{
        type = @(0);
        [dataDic setObject:recordMessage.body forKey:@"strContent"];
    }
    
    
    [dataDic setObject:type forKey:@"type"];
    
    [self dealTheFunctionData:dataDic];
    
}

- (void)dealTheFunctionData:(NSDictionary *)dic
{
    [self.chatModel addSpecifiedItem:dic];
    [self.chatTableView reloadData];
    [self tableViewScrollToBottom];
}

#pragma mark - UUInputFunctionViewDelegate
- (void)UUInputFunctionView:(UUInputFunctionView *)funcView sendMessage:(NSString *)message
{
    XMPPMessage * xmppMessage = [XMPPMessage messageWithType:@"chat" to:_chatJID];
    [xmppMessage addBody:message];
    [[LSTXXMMPStream sharedInstance].xmppStream sendElement:xmppMessage];
    
    funcView.textViewInput.text = @"";
    [funcView changeSendBtnWithPhoto:YES];
    //    [self dealTheFunctionData:dic];
}

//音频跟图片压缩后 base64编码
- (void)UUInputFunctionView:(UUInputFunctionView *)funcView sendPicture:(UIImage *)image
{
    NSString* encodeData = [UIImageJPEGRepresentation(image, 0.1) base64EncodedStringWithOptions:0];
    XMPPMessage* message = [[XMPPMessage alloc] initWithType:@"chat" to:_chatJID];
    [message addBody:encodeData];
    [message addSubject:@"picture"];
    [[LSTXXMMPStream sharedInstance].xmppStream sendElement:message];
}

- (void)UUInputFunctionView:(UUInputFunctionView *)funcView sendVoice:(NSData *)voice time:(NSInteger)second
{
    NSString* encodeData = [voice base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    XMPPMessage* message = [[XMPPMessage alloc] initWithType:@"chat" to:_chatJID];
    [message addBody:encodeData];
    [message addSubject:@"voice"];
    [message addAttributeWithName:@"VoiceLength" unsignedIntegerValue:second];
    [[LSTXXMMPStream sharedInstance].xmppStream sendElement:message];
}

#pragma mark - UUMessageCellDelegate
- (void)chatCell:(UUMessageCell *)cell headImageDidClick:(NSString *)userId {
    NSLog(@">>>>");
}

#pragma mark - UITableViewDataSource,UITableViewDelegate
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    [self.chatTableView.mj_header endRefreshing];
    return self.chatModel.dataSource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [self.chatModel.dataSource[indexPath.row] cellHeight];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UUMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CellID"];
    if (cell == nil) {
        cell = [[UUMessageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CellID"];
        cell.delegate = self;
    }
    [cell setMessageFrame:self.chatModel.dataSource[indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}

@end
