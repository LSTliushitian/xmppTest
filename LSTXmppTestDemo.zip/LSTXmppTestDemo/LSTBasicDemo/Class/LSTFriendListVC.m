//
//  LSTFriendListVC.m
//  LSTBasicDemo
//
//  Created by 兰科 on 2018/8/2.
//  Copyright © 2018年 兰科. All rights reserved.
//

#import "LSTFriendListVC.h"
#import "LSTChatVC.h"

@interface LSTFriendListVC ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView * tableView;//表格
@property (nonatomic, strong) NSMutableArray * friendList;//好友列表

@end

@implementation LSTFriendListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [[[LSTXXMMPStream sharedInstance] xmppRoster] fetchRoster];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rosterChange) name:@"RosterChanged" object:nil];
    
    [self.view addSubview:({
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, SafeAreaTopHeight, SCREENWIDTH, SCREENHEIGHT-SafeAreaTopHeight-SafeAreaBottomHeight+49) style:UITableViewStylePlain];
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorColor = RGB(51, 51, 51);
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _tableView.tableFooterView = [[UIView alloc] init];
        
        _tableView;
    })];
}

#pragma mark - 更新好友列表
- (void) rosterChange {
    _friendList = [NSMutableArray arrayWithArray:[LSTXXMMPStream sharedInstance].rosterMemoryStorage.unsortedUsers];
    NSLog(@">>>>>>>>>%@", _friendList);
    [_tableView reloadData];
}

#pragma mark - UITableViewDataSource, UITableViewDelegate
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _friendList.count;
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100*PIX;
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
    }
    
    XMPPUserMemoryStorageObject *user = [_friendList objectAtIndex:indexPath.row];
    
    cell.textLabel.text = user.jid.user;
    
    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    XMPPUserMemoryStorageObject *user = [_friendList objectAtIndex:indexPath.row];
    LSTChatVC *chatVC = [[LSTChatVC alloc] init];
    chatVC.chatJID = user.jid;
    [self.navigationController pushViewController:chatVC animated:YES];
}

@end
