//
//  LSTXXMPTestVC.m
//  LSTBasicDemo
//
//  Created by 兰科 on 2018/7/26.
//  Copyright © 2018年 兰科. All rights reserved.
//

#import "LSTXXMPTestVC.h"
#import "LSTXXMMPStream.h"
#import "LSTFriendListVC.h"

@interface LSTXXMPTestVC ()

@property (nonatomic, strong) UITextField * nameTF;
@property (nonatomic, strong) UITextField * passwordTF;

@end

@implementation LSTXXMPTestVC
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(registeSuccess) name:@"RegisteSuccess" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccess) name:@"LoginSuccess" object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"RegisteSuccess" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"LoginSuccess" object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:({
        _nameTF = [[UITextField alloc] initWithFrame:CGRectMake(50, 100, SCREENWIDTH-100, 30)];
        _nameTF.layer.borderColor = RGB(200, 200, 200).CGColor;
        _nameTF.layer.borderWidth = PIX;
        _nameTF.textColor = RGB(51, 51, 51);
        _nameTF.font = [UIFont systemFontOfSize:25];
        _nameTF.text = @"second";
        
        _nameTF;
    })];
    
    [self.view addSubview:({
        _passwordTF = [[UITextField alloc] initWithFrame:CGRectMake(50, 150, SCREENWIDTH-100, 30)];
        _passwordTF.layer.borderColor = RGB(200, 200, 200).CGColor;
        _passwordTF.layer.borderWidth = PIX;
        _passwordTF.textColor = RGB(51, 51, 51);
        _passwordTF.font = [UIFont systemFontOfSize:25];
        _passwordTF.text = @"second";
        
        _passwordTF;
    })];
    
    [self.view addSubview:({
        UIButton * registeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        registeBtn.frame = CGRectMake(50, 200, 100, 30);
        registeBtn.backgroundColor = [UIColor redColor];
        [registeBtn addTarget:self action:@selector(registeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        registeBtn;
    })];
    
    [self.view addSubview:({
        UIButton * loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        loginBtn.frame = CGRectMake(200, 200, 100, 30);
        loginBtn.backgroundColor = [UIColor orangeColor];
        [loginBtn addTarget:self action:@selector(loginBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        loginBtn;
    })];

}

#pragma mark - 按钮点击事件
- (void) registeBtnClick:(UIButton *) sender {
    [[LSTXXMMPStream sharedInstance] connect:_nameTF.text password:_passwordTF.text purpose:@"2"];
}

- (void) loginBtnClick:(UIButton *) sender {
    [[LSTXXMMPStream sharedInstance] connect:_nameTF.text password:_passwordTF.text purpose:@"1"];
}

- (void) registeSuccess {
    NSLog(@">>>>>>>>>%s", __func__);
}

- (void) loginSuccess {
    NSLog(@">>>>>>>%s", __func__);
    LSTFriendListVC * friendListVC = [[LSTFriendListVC alloc] init];
    friendListVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:friendListVC animated:YES];
}

@end
