//
//  LSTXXMMPStream.m
//  LSTBasicDemo
//
//  Created by 兰科 on 2018/7/27.
//  Copyright © 2018年 兰科. All rights reserved.
//

#import "LSTXXMMPStream.h" 

@interface LSTXXMMPStream ()<XMPPStreamDelegate, XMPPIncomingFileTransferDelegate>

@property (nonatomic, strong) XMPPIncomingFileTransfer * xmppIncomingFileTransfer;//接收文件

@property (nonatomic, strong) NSString * password;//密码
@property (nonatomic, strong) NSString * purpose;//用途 登录||注册

@end

@implementation LSTXXMMPStream
static LSTXXMMPStream * stream;
+ (instancetype) sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        stream = [[LSTXXMMPStream alloc] init];
        [stream setupStream];
    });
    
    return stream;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillTerminate) name:UIApplicationWillTerminateNotification object:nil];
        
    }
    return self;
}

#pragma mark - 初始化
- (void) setupStream {
    if (!_xmppStream) {
        _xmppStream = [[XMPPStream alloc] init];
        
        [_xmppStream setHostName:DOMAIN_HOST];//服务器地址
        [_xmppStream setHostPort:DOMAIN_PORT];
        [_xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];//设置stream代理
        [_xmppStream setKeepAliveInterval:600];//保持在线时间
        _xmppStream.enableBackgroundingOnSocket = YES;//后台模式
        
#pragma mark - 断线重连
        _xmppReconnect = [[XMPPReconnect alloc] init];
        [_xmppReconnect setAutoReconnect:YES];
        [_xmppReconnect activate:_xmppStream];
        
#pragma mark - 流模块管理
        XMPPStreamManagementMemoryStorage * storage = [[XMPPStreamManagementMemoryStorage alloc] init];
        _xmppStreamManagement = [[XMPPStreamManagement alloc] initWithStorage:storage];
        _xmppStreamManagement.autoResume = YES;
        [_xmppStreamManagement addDelegate:self delegateQueue:dispatch_get_main_queue()];//添加代理
        [_xmppStreamManagement activate:_xmppStream];//激活流模块
        
#pragma mark - 好友模块
        _rosterMemoryStorage = [[XMPPRosterMemoryStorage alloc] init];
        _xmppRoster = [[XMPPRoster alloc] initWithRosterStorage:_rosterMemoryStorage];
        [_xmppRoster activate:_xmppStream];//激活roster
        [_xmppRoster addDelegate:self delegateQueue:dispatch_get_main_queue()];//添加代理
        
#pragma mark - 聊天记录
        _archiving = [XMPPMessageArchivingCoreDataStorage sharedInstance];
        _messageArchiving = [[XMPPMessageArchiving alloc] initWithMessageArchivingStorage:_archiving dispatchQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 9)];
        [_messageArchiving addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 9)];//添加代理
        [_messageArchiving activate:_xmppStream];//激活管理对象
        _messageContext = _archiving.mainThreadManagedObjectContext;
        
        /**
#pragma mark - 文件接收
        _xmppIncomingFileTransfer = [[XMPPIncomingFileTransfer alloc] initWithDispatchQueue:dispatch_get_main_queue()];
        [_xmppIncomingFileTransfer activate:self.xmppStream];
        [_xmppIncomingFileTransfer addDelegate:self delegateQueue:dispatch_get_main_queue()];
        //设置为自动接收文件，当然也可以在代理方法中弹出一个alertView来让用户选择是否接收
        [_xmppIncomingFileTransfer setAutoAcceptFileTransfers:YES];
         */
        
    }
}

#pragma mark - 登录，注册
- (void) connect:(NSString *) userName password:(NSString *) password purpose:(NSString *)purpose {
    _password = password;
    _purpose = purpose;
    
    if ([_xmppStream isConnected]) {//断开连接
        [_xmppStream disconnect];
    }
    
    _xmppJID = [XMPPJID jidWithUser:userName domain:DOMAIN_HOST resource:@"iOS"];
    [_xmppStream setMyJID:_xmppJID];
    
    NSError * error = nil;
    [_xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error];
    if (error) {
        NSLog(@">>>>>error = %@", error);
    }
}

- (void) logOut {
    XMPPPresence * presence = [XMPPPresence presenceWithType:@"unavailable"];
    [_xmppStream sendElement:presence];
    
    [_xmppStream disconnectAfterSending];
}

/**
#pragma mark - 发送XML封装数据
- (void)sendXML:(NSString *)message image:(UIImage *)img voice:(NSData *)voice time:(NSUInteger)second{
    //生成xml
    //<body>
    NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
    [body setStringValue:message];
    //<message>
    NSXMLElement *mes = [NSXMLElement elementWithName:@"message"];
    //<message type = chat>
    [mes addAttributeWithName:@"type" stringValue:@"chat"];
    //<message type = "chat" to = _chatUserName>
    [mes addAttributeWithName:@"to" stringValue:_chatUserName];
    //<message type = "chat" to = _chatUserName from = ...>
    [mes addAttributeWithName:@"from" stringValue:[[NSUserDefaults standardUserDefaults] stringForKey:USERID]];
    //<message ...><body></body></message>
    [mes addChild:body];
    
    if (img) {
        //坑的我不轻的编码，这里因为png比较大（不清楚到底是转换出错还是xml有大小限制，但感觉是前者，毕竟好像base64是针对小文件编码的吧？），所以发送失败或接收不到(或者我得等个5分钟？)，所以选用压缩后传送。
        //        NSData *imgData = UIImagePNGRepresentation(img);
        NSData *imgData = UIImageJPEGRepresentation(img, 0.1);
        NSString *imgStr=[imgData base64EncodedStringWithOptions:0];
        //<message ...><body></body><img></img></message>
        NSXMLElement *imgAttachment = [NSXMLElement elementWithName:@"image"];
        [imgAttachment setStringValue:imgStr];
        [mes addChild:imgAttachment];
    }
    
    if (voice) {
        NSString *voiceStr = [voice base64EncodedStringWithOptions:0];
        NSXMLElement *voiceAttachment = [NSXMLElement elementWithName:@"voice"];
        [voiceAttachment setStringValue:voiceStr];
        [voiceAttachment addAttributeWithName:@"voiceTime" unsignedIntegerValue:second];
        [mes addChild:voiceAttachment];
    }
    
    //发送消息
    [[self xmppStream] sendElement:mes];
}
 
 */

#pragma mark - Connect Delegate
- (void)xmppStreamConnectDidTimeout:(XMPPStream *)sender {
     NSLog(@"连接服务器失败的方法，请检查网络是否正常");
}

- (void) xmppStream:(XMPPStream *)sender socketDidConnect:(GCDAsyncSocket *)socket {
    NSLog(@"连接成功");
}

- (void)xmppStreamDidConnect:(XMPPStream *)sender {
    NSLog(@"在发送密码授权");
    NSError * error = nil;
    switch (self.purpose.intValue) {
        case 1:
        {//登录
            [_xmppStream authenticateWithPassword:_password error:&error];
        }
            break;
        case 2:
        {//注册
            [_xmppStream registerWithPassword:_password error:&error];
        }
            break;
        default:
            break;
    }
    
    if (error) {
        NSLog(@">>>>>>%@", error);
    }
}

- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender {
    //登录成功
    XMPPPresence * presence = [XMPPPresence presenceWithType:@"available"];
    [_xmppStream sendElement:presence];
    NSLog(@">>>>>登录成功:%@", presence);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LoginSuccess" object:nil];
    [_xmppStreamManagement enableStreamManagementWithResumption:YES maxTimeout:0];//启动流管理
}

- (void) xmppStream:(XMPPStream *)sender didNotAuthenticate:(NSXMLElement *)error {
    NSLog(@"授权失败");
    [_xmppStream disconnect];
}

- (void) xmppStreamDidRegister:(XMPPStream *)sender {
    NSLog(@"注册成功");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RegisteSuccess" object:nil];
}

- (void) xmppStream:(XMPPStream *)sender didNotRegister:(NSXMLElement *)error {
    NSLog(@"注册失败>>%@", [error description]);
}

#pragma mark - Message Delegate
- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message {//收到消息
    NSLog(@"%s", __func__);
}

- (void)xmppStream:(XMPPStream *)sender didFailToSendMessage:(XMPPMessage *)message error:(NSError *)error {//发生消息失败
    NSLog(@"%s>>>%@", __func__, message);
}

#pragma mark - roster Delegate 好友相关代理
- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence {//好友更新状态
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RosterChanged" object:nil];
}

/**
#pragma mark - XMPPIncomingFileTransferDelegate 文件接收
- (void)xmppIncomingFileTransfer:(XMPPIncomingFileTransfer *)sender didReceiveSIOffer:(XMPPIQ *)offer {
    NSLog(@">>%s", __func__);
    [_xmppIncomingFileTransfer acceptSIOffer:offer];
}

//存储文件 音频为amr格式  图片为jpg格式
- (void)xmppIncomingFileTransfer:(XMPPIncomingFileTransfer *)sender didSucceedWithData:(NSData *)data named:(NSString *)name {
    XMPPJID *jid = [sender.senderJID copy];
    NSString *subject;
    NSString *extension = [name pathExtension];
    if ([@"amr" isEqualToString:extension]) {
        subject = @"voice";
    }else if([@"jpg" isEqualToString:extension]){
        subject = @"picture";
    }
    
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:jid];
    
    [message addAttributeWithName:@"from" stringValue:sender.senderJID.bare];
    [message addSubject:subject];
    
    NSString *path =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    path = [path stringByAppendingPathComponent:[XMPPStream generateUUID]];
    path = [path stringByAppendingPathExtension:extension];
    [data writeToFile:path atomically:YES];
    
    [message addBody:path.lastPathComponent];
    
    [self.archiving archiveMessage:message outgoing:NO xmppStream:self.xmppStream];
}
 */

#pragma mark - 程序即将退出
- (void) applicationWillTerminate {
    UIApplication * app = [UIApplication sharedApplication];
    UIBackgroundTaskIdentifier taskId = 0;
    
    taskId = [app beginBackgroundTaskWithExpirationHandler:^{
        [app endBackgroundTask:taskId];
    }];
    
    if (taskId == UIBackgroundTaskInvalid) {
        return;
    }
    
    [_xmppStream disconnectAfterSending];
    
}

@end
