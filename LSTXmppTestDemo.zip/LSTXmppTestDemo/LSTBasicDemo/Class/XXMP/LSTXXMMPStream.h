//
//  LSTXXMMPStream.h
//  LSTBasicDemo
//
//  Created by 兰科 on 2018/7/27.
//  Copyright © 2018年 兰科. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <XMPPFramework/XMPPFramework.h>
#import "XMPPIncomingFileTransfer.h"
#import "XMPPOutgoingFileTransfer.h"
#import <KissXML/KissXML.h>

@interface LSTXXMMPStream : NSObject

+ (instancetype) sharedInstance;

@property (nonatomic, strong) XMPPStream * xmppStream;
@property (nonatomic, strong) XMPPRoster * xmppRoster;//好友模块
@property (nonatomic, strong) XMPPRosterMemoryStorage * rosterMemoryStorage;
@property (nonatomic, strong) XMPPReconnect * xmppReconnect;//断线重连
@property (nonatomic, strong) XMPPStreamManagement * xmppStreamManagement;//流管理
@property (nonatomic, strong) XMPPMessageArchivingCoreDataStorage * archiving;
@property (nonatomic, strong) XMPPMessageArchiving * messageArchiving;//聊天记录
@property (nonatomic, strong) NSManagedObjectContext * messageContext;

@property (nonatomic, strong)   XMPPJID *xmppJID;

- (void) connect:(NSString *) userName password:(NSString *) password purpose:(NSString *)purpose; //1.登录 2.注册

@end
