//
//  LSTFriendListVC.h
//  LSTBasicDemo
//
//  Created by 兰科 on 2018/8/2.
//  Copyright © 2018年 兰科. All rights reserved.
//

#import "BasicViewController.h"

@interface LSTFriendListVC : BasicViewController

@end
