//
//  NSDictionary+DeleteNull.h
//  GoldLiving
//
//  Created by 李旋 on 2017/9/21.
//  Copyright © 2017年 YIYOU. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (DeleteNull)

+(id)changeType:(id)myObj;

@end
